"""Coffee TLV: three nearest verified coffee shops."""
import csv
import logging
import math
import os
from pathlib import Path
from urllib.parse import quote

from telegram import KeyboardButton, ReplyKeyboardMarkup, Update
from telegram.ext import Application, CommandHandler, ContextTypes, MessageHandler, filters

DATA_FILE = Path(__file__).with_name('cafes.csv')
logging.basicConfig(level=logging.INFO)


def distance_km(lat1, lon1, lat2, lon2):
    """Great-circle distance in kilometers (not walking distance)."""
    radius = 6371.0088
    p1, p2 = math.radians(lat1), math.radians(lat2)
    dp = math.radians(lat2 - lat1)
    dl = math.radians(lon2 - lon1)
    a = math.sin(dp / 2) ** 2 + math.cos(p1) * math.cos(p2) * math.sin(dl / 2) ** 2
    return radius * 2 * math.atan2(math.sqrt(a), math.sqrt(1 - a))


def load_cafes():
    valid = []
    with DATA_FILE.open(encoding='utf-8-sig', newline='') as f:
        for line, row in enumerate(csv.DictReader(f), start=2):
            try:
                if not row.get('latitude') or not row.get('longitude'):
                    continue
                if row.get('status', '').strip().lower() not in ('verified', 'active'):
                    continue
                lat, lon = float(row['latitude']), float(row['longitude'])
                if not (-90 <= lat <= 90 and -180 <= lon <= 180):
                    raise ValueError('coordinates out of range')
                row['lat'], row['lon'] = lat, lon
                valid.append(row)
            except (ValueError, TypeError):
                logging.warning('Invalid coordinates on CSV row %s', line)
    return valid


async def start(update: Update, context: ContextTypes.DEFAULT_TYPE):
    keyboard = ReplyKeyboardMarkup(
        [[KeyboardButton('📍 Send my location', request_location=True)]],
        resize_keyboard=True,
    )
    await update.message.reply_text(
        '☕ Coffee TLV\nSend your location and I’ll find the three nearest verified specialty coffee shops in our list.',
        reply_markup=keyboard,
    )


async def on_location(update: Update, context: ContextTypes.DEFAULT_TYPE):
    location = update.message.location
    cafes = load_cafes()
    if not cafes:
        await update.message.reply_text(
            'The coffee database has no verified coordinates yet. '
            'Add latitude and longitude to cafes.csv and set status=verified for each checked location.'
        )
        return
    nearest = sorted(cafes, key=lambda c: distance_km(location.latitude, location.longitude, c['lat'], c['lon']))[:3]
    lines = ['☕ Three nearest coffee shops (straight-line distance):']
    for index, cafe in enumerate(nearest, 1):
        km = distance_km(location.latitude, location.longitude, cafe['lat'], cafe['lon'])
        name = cafe['name'] + (f" — {cafe['branch']}" if cafe.get('branch') else '')
        address = cafe.get('address', '')
        # Coordinate-specific Maps URL avoids ambiguous place-name searches.
        maps = f"https://www.google.com/maps/search/?api=1&query={cafe['lat']},{cafe['lon']}"
        distance = f'{round(km * 1000)} m' if km < 1 else f'{km:.1f} km'
        lines.append(f'\n{index}. {name}\n📍 {address}\n📏 {distance}\n🗺 {maps}')
    await update.message.reply_text('\n'.join(lines), disable_web_page_preview=True)


def main():
    token = os.environ.get('TELEGRAM_BOT_TOKEN')
    if not token:
        raise SystemExit('Set TELEGRAM_BOT_TOKEN in your environment first.')
    app = Application.builder().token(token).build()
    app.add_handler(CommandHandler('start', start))
    app.add_handler(MessageHandler(filters.LOCATION & filters.ChatType.PRIVATE, on_location))
    app.run_polling()


if __name__ == '__main__':
    main()

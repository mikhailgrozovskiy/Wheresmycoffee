# Coffee TLV Telegram Bot

A Python Telegram bot that returns the three nearest verified coffee shops from `cafes.csv`.

## Setup

1. Install Python 3.10+.
2. In Telegram, open `@BotFather`, send `/newbot`, and copy the bot token. Keep it private.
3. Open a terminal in this folder.
4. Install dependencies: `python -m pip install -r requirements.txt`
5. Set the token:
   - macOS/Linux: `export TELEGRAM_BOT_TOKEN='YOUR_TOKEN'`
   - Windows PowerShell: `$env:TELEGRAM_BOT_TOKEN='YOUR_TOKEN'`
6. Run: `python bot.py`
7. Open your bot in Telegram, send `/start`, and tap **Send my location** (private chat).

## IMPORTANT: database preparation

The supplied CSV has unverified addresses and blank coordinates. The bot **will not invent** coordinates or rank unverified rows.

For each cafe, check its exact location and whether it is open, then fill in:
- `latitude`: decimal latitude, e.g. `32.08000` (illustrative only)
- `longitude`: decimal longitude, e.g. `34.78000` (illustrative only)
- `status`: `verified`

Keep unverified rows as `address_to_verify`. A row with no coordinates is skipped. The bot will display a setup message until at least one verified row has coordinates.

## Notes

- Distances are **straight-line**, not walking distances.
- One row = one physical cafe branch.
- No user's location is stored by this script.
- This bot works while the Python process is running. For 24/7 availability, deploy it on an always-on host.
